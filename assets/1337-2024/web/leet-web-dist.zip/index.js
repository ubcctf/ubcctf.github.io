const nodeAPI = require("node-api");

const secret = await Bun.file("flag1.txt").text()
const sign = (data) => Buffer.from(nodeAPI.crypto.createHmac("sha256", secret).update(data).digest()).toString('base64');
const verify = (data, signature) => sign(data) === signature;
const parseCookies = (cookieHeader) => cookieHeader?.split(";").map(c => c.trim().split("=")).reduce((a, [k, ...v]) => ({ ...a, [k]: v.join("=") }), {});
const defaultAuth = { "role": "user" };

const server = Bun.serve({
    host: "0.0.0.0",
    port: 80,
    async fetch(req) {
        let cookies = parseCookies(req.headers.get("Cookie")) ?? {};
        let [authInfo, token] = cookies.token ? cookies.token.split(".") : [undefined, undefined];
        let responseOpts = authInfo ? {} : { "headers": { "Set-Cookie": `token=${btoa(JSON.stringify(defaultAuth))}.${sign(JSON.stringify(defaultAuth))};` } };
        let userAuth = token && verify(atob(authInfo), token) ? JSON.parse(atob(authInfo)) : defaultAuth;
        let pathname = new URL(req.url).pathname;
        try {
            let decodedPathName = decodeURIComponent(pathname.slice(1));
            if (decodedPathName.includes("flag2")) {
                if (userAuth.role !== "admin") return new Response("no", { ...responseOpts, status: 401 });
            }
            const file = pathname && pathname != "/" ?  decodedPathName : "index.html";
            return new Response(await Bun.file(file).text(), responseOpts);
        } catch (e) { return new Response(e, {...responseOpts, status: 500}) };
    },
});
console.log(`Listening on http://0.0.0.0:${server.port}`);

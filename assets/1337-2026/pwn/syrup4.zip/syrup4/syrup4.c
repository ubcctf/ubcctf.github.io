/* gcc syrup4.c -o syrup4 -no-pie -fno-stack-protector */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void init() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

void bottle() {
    char syrup[256];
    puts("🍁 Pour the maple syrup:");
    read(0, syrup, 0x200);  // oops, spilled syrup everywhere
}

int main() {
    init();
    bottle();
    return 0;
}

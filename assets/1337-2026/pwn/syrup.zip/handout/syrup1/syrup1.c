/* gcc syrup1.c -o syrup1 -no-pie -fno-stack-protector */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

const int is_admin = 0;

void win() {
    // Haha, now you must be admin to call this function!
    if (is_admin) {
        system("/bin/sh");
    }
}

void init() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

void bottle() {
    char syrup[256];
    puts("🍁 Pour the maple syrup:");
    read(0, syrup, 0x200);  // oops, spilled syrup everywhere
}

int main() {
    init();
    bottle();
    return 0;
}

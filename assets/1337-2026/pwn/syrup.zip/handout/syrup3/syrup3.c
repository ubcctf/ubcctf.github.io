/* gcc syrup3.c -o syrup3 -no-pie -fno-stack-protector */

// Hint: if you don't have a leak, can you create one?
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void win() {
    __asm__("pop %rdi; ret");
}

void init() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

void bottle() {
    char syrup[256];
    puts("🍁 Pour the maple syrup:");
    read(0, syrup, 0x200);  // oops, spilled syrup everywhere
}

int main() {
    init();
    bottle();
    return 0;
}

/* gcc syrup0.c -o syrup0 -no-pie -fno-stack-protector */

// Hint: if you are getting segfault, recall "stack alignment" on 64-bit systems.
// https://ir0nstone.gitbook.io/notes/binexp/stack/return-oriented-programming/stack-alignment
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void win() {
    system("/bin/sh");
}

void init() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

void bottle() {
    char syrup[256];
    puts("🍁 Pour the maple syrup:");
    read(0, syrup, 0x200);  // oops, spilled syrup everywhere
}

int main() {
    init();
    bottle();
    return 0;
}

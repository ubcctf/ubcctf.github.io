/* gcc syrup2.c -o syrup2 -no-pie -fno-stack-protector */

// Hint 1: look up "return-oriented programming" (a.k.a. ROP)
// Hint 2: you may need the libc.so.6, consider using `patchelf` to make the binary load
// the given libc instead of your system's libc.
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void win() {
    // Haha, what can you do with a function pointer?
    printf("system @ %p\n", system);
}

void init() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

void bottle() {
    char syrup[256];
    puts("🍁 Pour the maple syrup:");
    read(0, syrup, 0x200);  // oops, spilled syrup everywhere
}

int main() {
    init();
    bottle();
    return 0;
}
